"""Dashboard components module."""
